package com.magadistudio.animals;

public class Lion extends Animal{

	@Override
	public void makeNoise() {
		System.out.println("Roar...");
		
	}
	

	
	

}
