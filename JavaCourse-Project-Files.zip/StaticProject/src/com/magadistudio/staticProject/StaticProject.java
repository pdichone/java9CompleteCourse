package com.magadistudio.staticProject;

import java.util.jar.Attributes.Name;

public class StaticProject {
	
	private static String name;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int myValue = -45;
		int secondValue = 56;
		
	
		StaticProject myProject = new StaticProject();
		
		System.out.println();
		
//		int x = Math.min(myValue, secondValue);
//		int y = Math.abs(myValue);
//		
//		System.out.println("X Min: " + x + " Y Abs: " + y);
		
		
		
	
	}
	
	public static void setName(String n) {
		
		name = n;
		
	}
	


}


