package com.magadistudio.controlstatement;

public class Controls {

	public static void main(String[] args) {
		/*
		 * 
		 * if statement
		 * 
		 *  == --> equal (comparison) = Relational Operators
		 *  != --> Not Equal
		 *  > --> greater than
		 *  < --> Less than
		 *  >= -->Greater than or equal
		 *  <= --> Less than or equal
		 *  
		 *  === Logical Operators
		 *   AND ( && ) --> if one variable is false, than the entire condition returns false
		 *   OR ( || ) --> opposite of AND: if one variable is true, than the condition returns true
		 *   NOT ( ! )
		 * 
		 */
		
		int a = 1;
		int b = 3;
		
		boolean first = false;
		boolean second = true;
		
		
		
		if ( a == 1 && first == second) {
			System.out.println("Yes!");
		}
		
//		if (a == b) {
//			
//			System.out.println("Yes it's true");
//			
//		}else {
//			
//			System.out.print("Hello");
//		}
		

	}

}
