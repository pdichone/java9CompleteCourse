package com.magadistudio.loops;

public class Loops {

	public static void main(String[] args) {
		
		/*
		 *  for loop
		 *  while loop
		 *  do... while loop
		 *  
		 */
		
		int counter = 1;
		
		do {
			System.out.println("counter: " + counter);
			counter++;
			
		} while (counter < 11);
		
//		while (counter < 11) {
//			System.out.println("Count is: " + counter);
//			counter++;
//		}
		
		
//		for (int i = 0; i < 18; i++) {
//			
//			System.out.println("Running " + i);
//			
//		}

	}

}
