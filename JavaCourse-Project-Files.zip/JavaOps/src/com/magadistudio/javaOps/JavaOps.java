package com.magadistudio.javaOps;

public class JavaOps {

	public static void main(String[] args) {
		
		
		/*
		 *  Addition ( + )
		 *  
		 *  Multiplication ( * )
		 *  
		 *  Division ( / )
		 *  
		 *  Subtraction ( - )
		 *  
		 *  Remainder ( % ) - "what remains..." 5 % 2
		 */
		
		int firstNum 	= 8;
		int secondNum 	= 7;
		int result 		= 0;
		
		result = firstNum % secondNum;
		
		System.out.println("Result: " + result );

	}

}
