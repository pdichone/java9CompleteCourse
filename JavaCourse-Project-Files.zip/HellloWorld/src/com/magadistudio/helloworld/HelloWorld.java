package com.magadistudio.helloworld;

import javax.xml.bind.ParseConversionEvent;

public class HelloWorld {

	public static void main(String[] args) {
		
		
		//StringBuilder class
		
		StringBuilder stringBuilder = new StringBuilder();
		Number number = 34.54;
		
		stringBuilder.append("Hello");
		stringBuilder.append("Paulo");
		stringBuilder.append('C');
		stringBuilder.delete(1, 3);
		
		String myString = stringBuilder.toString();
		

		
		
		
		System.out.println(stringBuilder + " length: " + stringBuilder.length());
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
		/* Variables  = container 
		 * 
		 * Integer = number
		 * 
		 * byte  = smallest "container" or memory space we can use
		 * 
		 * Short = 2x the size of a byte
		 * 
		 * Float = 1.89
		 * 
		 * Double = 23.89
		 * 
		 * char = character (*, &, @...)
		 * 
		 * Boolean = holds 2 states ==> true and false; or 1 and 0
		 
		 */
//		String myName = "Paulo";
//		String myDog = "Jerry";
//		String myMom = "Gina";
//		
//		int myNumber = 1247877798;
//		int anotherNumber = 34;
//		
//		byte myByte = 127;
//		
//		short myShort = 4956;
//		
//		float myfloat = 2.9f;
//		
//		double myDouble = 34.78;
//		
//		char myChar = 'C';
//		
//		
//		boolean myBoolean = false;
		
		
	
		
//		System.out.println(myName + " has " + myNumber + " Oranges ");
//		System.out.println(myDog + " has " + anotherNumber + " puppies ");
//		System.out.println(" Byte " + myByte + " short " 
//		                     + myShort + " float " + myfloat 
//		                     + " double " + myDouble + " Char " + myChar + " Boolean " +
//		                     myBoolean);
		
		


	}

}
