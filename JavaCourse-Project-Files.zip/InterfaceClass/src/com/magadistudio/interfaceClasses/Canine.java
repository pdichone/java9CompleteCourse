package com.magadistudio.interfaceClasses;

public class Canine extends Animal {
	
	private String typeTeeth;
	

	public String getTypeTeeth() {
		return typeTeeth;
	}

	public void setTypeTeeth(String typeTeeth) {
		this.typeTeeth = typeTeeth;
	}
	
	
	

}
