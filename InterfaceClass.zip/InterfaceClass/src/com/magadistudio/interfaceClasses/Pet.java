package com.magadistudio.interfaceClasses;

public interface Pet {
	
	abstract void beFriendly();
	abstract void play();

}
