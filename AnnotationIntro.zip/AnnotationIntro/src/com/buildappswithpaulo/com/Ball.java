package com.buildappswithpaulo.com;


public class Ball {

    @Deprecated
    public void bounce() {
        System.out.println("Bounce");
    }
}
