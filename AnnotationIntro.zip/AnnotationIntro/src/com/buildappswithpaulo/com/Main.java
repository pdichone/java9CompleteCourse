package com.buildappswithpaulo.com;

public class Main {


    public static void main(String[] args) {

        Basketball basketball = new Basketball();
        basketball.bounce();
    }
}
