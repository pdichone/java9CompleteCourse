package com.buildappswithpaulo.com;

public class Basketball extends Ball{


    @Override
    public void bounce(){
        System.out.println("Basketball bouncing...");
    }
}
