package com.gohooljava.com;

public class Main {

    public static void main(String[] args) {

        Tub myTub = new Tub(13);

        System.out.println(myTub.getSize() + " " + myTub.getBubbleColor());


    }
}
