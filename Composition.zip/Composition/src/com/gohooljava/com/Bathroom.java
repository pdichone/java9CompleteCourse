package com.gohooljava.com;

public class Bathroom {
    private Tub bathtub;
}
