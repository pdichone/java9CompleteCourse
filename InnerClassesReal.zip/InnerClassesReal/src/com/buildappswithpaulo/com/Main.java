package com.buildappswithpaulo.com;

public class Main {

    public static void main(String[] args) {
	    Ball ball = new Ball();

	    ball.setUpBall();
    }
}
