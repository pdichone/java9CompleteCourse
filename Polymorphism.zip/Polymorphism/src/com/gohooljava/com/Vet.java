package com.gohooljava.com;

public class Vet {
    public void giveShot(Animal animal) {
        animal.makeSound();
    }
}
