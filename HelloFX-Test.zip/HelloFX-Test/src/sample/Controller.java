package sample;

import javafx.event.ActionEvent;

public class Controller {

    public void pressed(ActionEvent event) {

        System.out.println("Hello");


    }
}
